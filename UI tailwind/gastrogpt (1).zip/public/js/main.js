document.addEventListener("DOMContentLoaded", () => {
  // Inicializar la funcionalidad según la página activa
  const path = window.location.pathname

  if (path === "/" || path === "") {
    initChat()
  } else if (path === "/preferences") {
    initPreferences()
  } else if (path === "/menu") {
    initMenu()
  }
})

// Funcionalidad del Chat
function initChat() {
  const chatInput = document.getElementById("chat-input")
  const sendButton = document.getElementById("send-button")
  const chatMessages = document.getElementById("chat-messages")

  if (!chatInput || !sendButton || !chatMessages) return

  sendButton.addEventListener("click", sendMessage)
  chatInput.addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
      sendMessage()
    }
  })

  function sendMessage() {
    const message = chatInput.value.trim()
    if (!message) return

    // Añadir mensaje del usuario
    const userMessageTime = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    const userMessageHTML = `
      <div class="message user">
        <div class="avatar">TÚ</div>
        <div class="message-content">
          <p>${escapeHTML(message)}</p>
          <div class="message-time">${userMessageTime}</div>
        </div>
      </div>
    `
    chatMessages.insertAdjacentHTML("beforeend", userMessageHTML)
    chatInput.value = ""

    // Hacer scroll hacia abajo
    chatMessages.scrollTop = chatMessages.scrollHeight

    // Simular respuesta del bot (en una aplicación real, esto vendría de una API)
    setTimeout(() => {
      const botMessageTime = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      const botMessageHTML = `
        <div class="message bot">
          <div class="avatar">GP</div>
          <div class="message-content">
            <p>Gracias por tu mensaje. ¿Te gustaría conocer nuestras recomendaciones del día o tienes alguna pregunta específica sobre el menú?</p>
            <div class="message-time">${botMessageTime}</div>
          </div>
        </div>
      `
      chatMessages.insertAdjacentHTML("beforeend", botMessageHTML)
      chatMessages.scrollTop = chatMessages.scrollHeight
    }, 1000)
  }
}

// Funcionalidad de Preferencias
function initPreferences() {
  const preferencesForm = document.getElementById("preferences-form")

  if (!preferencesForm) return

  preferencesForm.addEventListener("submit", (e) => {
    e.preventDefault()

    // En una aplicación real, aquí enviaríamos los datos a un servidor
    // Por ahora, solo mostraremos una alerta
    alert("¡Preferencias guardadas correctamente!")
  })
}

// Funcionalidad del Menú
function initMenu() {
  const searchInput = document.getElementById("search-menu")
  const menuTabs = document.querySelectorAll(".menu-tab")
  const menuItems = document.getElementById("menu-items")
  const modal = document.getElementById("dish-modal")
  const closeModal = document.querySelector(".close-modal")

  if (!searchInput || !menuTabs.length || !menuItems || !modal || !closeModal) return

  // Datos del menú
  const menuData = {
    entrantes: [
      {
        id: 1,
        nombre: "Croquetas de Jamón",
        descripcion: "Deliciosas croquetas caseras de jamón ibérico con bechamel cremosa",
        precio: 8.5,
        imagen: "/placeholder.svg?height=200&width=300",
        alergenos: ["gluten", "lactosa"],
        etiquetas: ["popular"],
      },
      {
        id: 2,
        nombre: "Ensalada César",
        descripcion: "Lechuga romana, pollo a la parrilla, crutones, queso parmesano y aderezo César",
        precio: 9.75,
        imagen: "/placeholder.svg?height=200&width=300",
        alergenos: ["gluten", "lactosa", "huevo"],
        etiquetas: [],
      },
      {
        id: 3,
        nombre: "Gazpacho Andaluz",
        descripcion: "Sopa fría tradicional de tomate, pepino, pimiento y ajo",
        precio: 6.5,
        imagen: "/placeholder.svg?height=200&width=300",
        alergenos: [],
        etiquetas: ["vegano", "sin_gluten"],
      },
    ],
    principales: [
      {
        id: 4,
        nombre: "Paella de Mariscos",
        descripcion: "Arroz con azafrán, calamares, gambas, mejillones y almejas",
        precio: 18.5,
        imagen: "/placeholder.svg?height=200&width=300",
        alergenos: ["mariscos"],
        etiquetas: ["popular", "recomendado"],
      },
      {
        id: 5,
        nombre: "Solomillo al Whisky",
        descripcion: "Solomillo de ternera con salsa de whisky, acompañado de patatas asadas",
        precio: 22.0,
        imagen: "/placeholder.svg?height=200&width=300",
        alergenos: [],
        etiquetas: ["recomendado"],
      },
      {
        id: 6,
        nombre: "Risotto de Setas",
        descripcion: "Arroz cremoso con variedad de setas silvestres y queso parmesano",
        precio: 14.5,
        imagen: "/placeholder.svg?height=200&width=300",
        alergenos: ["lactosa"],
        etiquetas: ["vegetariano"],
      },
    ],
    postres: [
      {
        id: 7,
        nombre: "Tarta de Queso",
        descripcion: "Tarta cremosa de queso con base de galleta y coulis de frutos rojos",
        precio: 6.5,
        imagen: "/placeholder.svg?height=200&width=300",
        alergenos: ["gluten", "lactosa", "huevo"],
        etiquetas: ["popular"],
      },
      {
        id: 8,
        nombre: "Crema Catalana",
        descripcion: "Postre tradicional catalán con crema suave y cobertura de azúcar caramelizado",
        precio: 5.75,
        imagen: "/placeholder.svg?height=200&width=300",
        alergenos: ["lactosa", "huevo"],
        etiquetas: [],
      },
      {
        id: 9,
        nombre: "Sorbete de Limón",
        descripcion: "Refrescante sorbete de limón, perfecto para limpiar el paladar",
        precio: 4.5,
        imagen: "/placeholder.svg?height=200&width=300",
        alergenos: [],
        etiquetas: ["vegano", "sin_gluten"],
      },
    ],
    bebidas: [
      {
        id: 10,
        nombre: "Vino Tinto Rioja Reserva",
        descripcion: "Vino tinto con 24 meses de crianza en barrica de roble",
        precio: 18.0,
        imagen: "/placeholder.svg?height=200&width=300",
        alergenos: [],
        etiquetas: ["recomendado"],
      },
      {
        id: 11,
        nombre: "Sangría Casera",
        descripcion: "Refrescante sangría con vino tinto, frutas y un toque de canela",
        precio: 12.5,
        imagen: "/placeholder.svg?height=200&width=300",
        alergenos: [],
        etiquetas: ["popular"],
      },
      {
        id: 12,
        nombre: "Agua Mineral",
        descripcion: "Agua mineral natural de manantial",
        precio: 2.0,
        imagen: "/placeholder.svg?height=200&width=300",
        alergenos: [],
        etiquetas: [],
      },
    ],
  }

  // Cargar los entrantes por defecto
  loadMenuItems("entrantes")

  // Manejar cambios de pestaña
  menuTabs.forEach((tab) => {
    tab.addEventListener("click", function () {
      menuTabs.forEach((t) => t.classList.remove("active"))
      this.classList.add("active")
      loadMenuItems(this.dataset.tab)
    })
  })

  // Manejar búsqueda
  searchInput.addEventListener("input", function () {
    const searchTerm = this.value.toLowerCase()
    const activeTab = document.querySelector(".menu-tab.active").dataset.tab
    loadMenuItems(activeTab, searchTerm)
  })

  // Cerrar modal
  closeModal.addEventListener("click", () => {
    modal.style.display = "none"
  })

  // Cerrar modal al hacer clic fuera
  window.addEventListener("click", (e) => {
    if (e.target === modal) {
      modal.style.display = "none"
    }
  })

  function loadMenuItems(category, searchTerm = "") {
    let items = []

    if (category === "destacados") {
      // Combinar todos los platos y filtrar los destacados
      const allItems = [...menuData.entrantes, ...menuData.principales, ...menuData.postres, ...menuData.bebidas]

      items = allItems.filter((item) => item.etiquetas.includes("popular") || item.etiquetas.includes("recomendado"))
    } else {
      items = menuData[category] || []
    }

    // Filtrar por término de búsqueda si existe
    if (searchTerm) {
      items = items.filter(
        (item) => item.nombre.toLowerCase().includes(searchTerm) || item.descripcion.toLowerCase().includes(searchTerm),
      )
    }

    // Limpiar y renderizar los elementos
    menuItems.innerHTML = ""

    if (items.length === 0) {
      menuItems.innerHTML = '<p class="text-center py-4">No se encontraron platos que coincidan con tu búsqueda.</p>'
      return
    }

    items.forEach((item) => {
      const itemHTML = createMenuItemHTML(item)
      menuItems.insertAdjacentHTML("beforeend", itemHTML)
    })

    // Añadir event listeners a los botones "Ver más"
    document.querySelectorAll(".view-dish-details").forEach((button) => {
      button.addEventListener("click", function () {
        const itemId = Number.parseInt(this.dataset.id)
        const category = this.dataset.category
        const item = menuData[category].find((i) => i.id === itemId)

        if (item) {
          showDishDetails(item)
        }
      })
    })
  }

  function createMenuItemHTML(item) {
    // Determinar la categoría del plato
    let category = ""
    for (const [cat, items] of Object.entries(menuData)) {
      if (items.some((i) => i.id === item.id)) {
        category = cat
        break
      }
    }

    return `
      <div class="menu-item">
        <div class="menu-item-image-container">
          <img src="${item.imagen}" alt="${item.nombre}" class="menu-item-image">
          <div class="menu-item-badges">
            ${item.etiquetas.includes("popular") ? '<span class="badge badge-popular">⭐ Popular</span>' : ""}
            ${item.etiquetas.includes("recomendado") ? '<span class="badge badge-recommended">👨‍🍳 Recomendado</span>' : ""}
          </div>
        </div>
        <div class="menu-item-content">
          <div class="menu-item-header">
            <h3 class="menu-item-title">${item.nombre}</h3>
            <span class="menu-item-price">${item.precio.toFixed(2)}€</span>
          </div>
          <p class="menu-item-description">${item.descripcion}</p>
          <div class="menu-item-allergens">
            ${item.alergenos.map((alergeno) => `<span class="allergen-tag">${getAlergenoIcon(alergeno)}</span>`).join("")}
          </div>
          <button class="btn btn-outline btn-full view-dish-details" data-id="${item.id}" data-category="${category}">Ver más</button>
        </div>
      </div>
    `
  }

  function showDishDetails(item) {
    document.getElementById("modal-title").textContent = item.nombre
    document.getElementById("modal-price").textContent = `${item.precio.toFixed(2)}€`
    document.getElementById("modal-image").src = item.imagen
    document.getElementById("modal-image").alt = item.nombre
    document.getElementById("modal-description").textContent = item.descripcion

    // Alérgenos
    const allergenContainer = document.getElementById("modal-allergens-container")
    const allergenTags = document.getElementById("modal-allergens")

    if (item.alergenos.length > 0) {
      allergenContainer.style.display = "block"
      allergenTags.innerHTML = item.alergenos
        .map((alergeno) => `<span class="modal-tag tag-allergen">${getAlergenoIcon(alergeno)} ${alergeno}</span>`)
        .join("")
    } else {
      allergenContainer.style.display = "none"
    }

    // Etiquetas
    const tagsContainer = document.getElementById("modal-tags-container")
    const tagsList = document.getElementById("modal-tags")

    if (item.etiquetas.length > 0) {
      tagsContainer.style.display = "block"
      tagsList.innerHTML = item.etiquetas
        .map((etiqueta) => `<span class="modal-tag ${getEtiquetaClass(etiqueta)}">${getEtiquetaLabel(etiqueta)}</span>`)
        .join("")
    } else {
      tagsContainer.style.display = "none"
    }

    // Mostrar modal
    modal.style.display = "block"
  }

  function getAlergenoIcon(alergeno) {
    switch (alergeno) {
      case "gluten":
        return "🌾"
      case "lactosa":
        return "🥛"
      case "huevo":
        return "🥚"
      case "mariscos":
        return "🦐"
      case "frutos_secos":
        return "🥜"
      case "soja":
        return "🫘"
      default:
        return "⚠️"
    }
  }

  function getEtiquetaLabel(etiqueta) {
    switch (etiqueta) {
      case "popular":
        return "Popular"
      case "recomendado":
        return "Recomendado por el chef"
      case "vegano":
        return "Vegano"
      case "vegetariano":
        return "Vegetariano"
      case "sin_gluten":
        return "Sin gluten"
      default:
        return etiqueta
    }
  }

  function getEtiquetaClass(etiqueta) {
    switch (etiqueta) {
      case "popular":
        return "tag-popular"
      case "recomendado":
        return "tag-recommended"
      case "vegano":
        return "tag-vegan"
      case "vegetariano":
        return "tag-vegetarian"
      case "sin_gluten":
        return "tag-gluten-free"
      default:
        return ""
    }
  }
}

// Función de utilidad para escapar HTML
function escapeHTML(str) {
  return str.replace(
    /[&<>'"]/g,
    (tag) =>
      ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        "'": "&#39;",
        '"': "&quot;",
      })[tag],
  )
}
