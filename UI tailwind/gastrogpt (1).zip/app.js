const express = require("express")
const path = require("path")
const app = express()
const port = process.env.PORT || 3000

// Configuración de EJS como motor de plantillas
app.set("view engine", "ejs")
app.set("views", path.join(__dirname, "views"))

// Servir archivos estáticos desde la carpeta public
app.use(express.static(path.join(__dirname, "public")))

// Rutas
app.get("/", (req, res) => {
  res.render("index", {
    activeTab: "chat",
    title: "GastroGPT - Asistente Virtual Gastronómico",
  })
})

app.get("/preferences", (req, res) => {
  res.render("index", {
    activeTab: "preferences",
    title: "GastroGPT - Preferencias",
  })
})

app.get("/menu", (req, res) => {
  res.render("index", {
    activeTab: "menu",
    title: "GastroGPT - Carta Digital",
  })
})

// Iniciar el servidor
app.listen(port, () => {
  console.log(`Servidor ejecutándose en http://localhost:${port}`)
})
